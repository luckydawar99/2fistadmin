import React from 'react'

const Payment = () => {
  return (
    <div>
      sdsad
    </div>
  )
}

export default Payment
