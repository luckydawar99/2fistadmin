import React from 'react'
import Payment from './Payment'

const Test = () => {
  return (
    <div>
        <Payment/>
    </div>
  )
}

export default Test
